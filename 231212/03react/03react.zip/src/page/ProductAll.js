import React from "react";

const ProductAll = () => {
  return <div>Product All</div>;
};

export default ProductAll;
