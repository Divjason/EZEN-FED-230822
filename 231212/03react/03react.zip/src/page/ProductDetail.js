import React from "react";

const ProductDetail = () => {
  return <div>Product Detail</div>;
};

export default ProductDetail;
