import React from "react";

const ProductCard = () => {
  return <div>Product Card</div>;
};

export default ProductCard;
ProductCard;
