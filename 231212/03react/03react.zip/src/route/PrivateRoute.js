import React from "react";

const PrivateRoute = () => {
  return <div>Private Route</div>;
};

export default PrivateRoute;
